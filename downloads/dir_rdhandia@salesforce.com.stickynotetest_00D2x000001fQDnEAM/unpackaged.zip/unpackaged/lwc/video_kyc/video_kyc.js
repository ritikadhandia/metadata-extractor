import { LightningElement, track } from 'lwc';
import fetchIdentityNo from '@salesforce/apex/VisionController.fetchIdentityNo';
import verifyCard from '@salesforce/apex/VisionController.verifyCard';
import validateCard from '@salesforce/apex/VisionController.validateCard';
import createContentUrl from '@salesforce/apex/VisionController.createContentUrl';
import Id from '@salesforce/user/Id';

export default class video_kyc extends LightningElement {

    userId = Id;
    fileReader;
    MAX_FILE_SIZE = 2000000;
    file;
    fileContents;
    @track fileName;
    contentUrl;


    @track firstName;
    @track LastName;
    @track dob;
    @track gender;

    @track detectStarted = false;
    @track ocrStarted = false;
    @track apiStarted =false;
    @track apiPANCompleted = false;
    @track apiAADCompleted = false;
    @track uploadDisabled = false;
    @track aadWaiting = false;
    @track detectIcon ='action:new_note';
    @track ocrIcon ='action:new_note';
    @track apiIcon ='action:new_note';

    @track verifiedCard;
    @track detectedId;
    @track detectedCardType;
    @track apiStatus;
    @track apiResponse;

    constructor() {
        super();
        this.template.addEventListener('notification', evt => {
            console.log('Notification event', evt);
        });

        window.addEventListener("message", (message) => {
            if (message !== undefined && message.data != undefined) {
                var data = JSON.parse(message.data);
                if(data.body && data.body.event.name == 'screenCapture'){
                    this.fileContents = data.body.event.payload.data;
                   // this.fileContents = this.fileReader.result;
                    let base64 = 'base64,';
                    let content = this.fileContents.indexOf(base64) + base64.length;
                    this.fileContents = this.fileContents.substring(content);
                    // Step 1 - Id Card Verification
                    this.cardVerification();
                }
            }
        }
    );
    }

    renderedCallback(){
    }

    resetStatus(){
        this.detectStarted = false;
        this.ocrStarted = false;
        this.apiStarted =false;
        this.apiPANCompleted = false;
        this.apiAADCompleted = false;
        this.uploadDisabled = false;
        this.aadWaiting = false;
        this.detectIcon ='action:new_note';
        this.ocrIcon ='action:new_note';
        this.apiIcon ='action:new_note';
        this.verifiedCard = '';
        this.detectedId = '';
        this.apiStatus = '';
    }

    get detectStatus(){
        return this.detectStarted;
    }

    idValidation(){
        this.apiStarted = true;
        validateCard({ cardType: this.detectedCardType, cardNo: this.detectedId})
        .then(result => {
            console.log(result);
            this.apiStarted = false;
            this.uploadDisabled = false;
            if(result){
                this.apiIcon = 'action:approval';
                this.apiStatus = 'Valid and Active '+ this.detectedCardType;
                this.apiResponse = result;
                if(this.detectedCardType == 'PAN'){
                    this.apiPANCompleted = true;
                }
                else{
                    if(this.apiResponse.TransactionStatus == 'CKYCRejected'){
                        this.apiIcon = 'action:close';
                    }
                    this.apiAADCompleted = true;
                    this.aadWaiting = false;
                }
            }
            else{
                this.apiIcon = 'action:close';
                this.apiStatus = 'Invalid or Inactive '+ this.detectedCardType;
            }
        })
        .catch(error => {
            this.apiStarted = false;
            this.uploadDisabled = false;
            this.apiIcon = 'action:close';
            this.apiStatus = 'Unable to Validate '+this.detectedCardType;
        });
    }

    ocrDetection(){
        this.ocrStarted = true;
        fetchIdentityNo({ cardType: this.detectedCardType, base64Data: this.fileContents})
        .then(result => {
            this.ocrStarted = false;
            if(result != ''){
                this.detectedId = result;
                this.ocrIcon = 'action:approval';
                if(this.detectedCardType == 'PAN'){
                   // this.idValidation();
                    this.apiIcon = 'action:approval';
                    this.apiStatus = 'Valid and Active '+ this.detectedCardType;
                }
                else{
                    this.aadWaiting = true;
                }
            }
            else{
                this.ocrIcon = 'action:close';
                this.detectedId = 'No Valid Id found';
            }
        })
        .catch(error => {
            this.ocrStarted = false;
            this.uploadDisabled = false;
            this.ocrIcon = 'action:close';
            this.detectedId = 'No Valid Id found';
        });
    }

    cardVerification(){
            this.detectStarted = true;
            this.uploadDisabled = true;
            console.log('Verify Card');
            verifyCard({ base64Data: this.fileContents})
            .then(result =>{
                this.detectStarted = false;
                this.detectIcon = 'action:approval';
                if(result.cardType){
                    this.detectedCardType = result.cardType
                    this.verifiedCard = 'Detected Image as '+ result.cardType + ' matching ' + (result.cardProbability*100).toFixed(2) +'%';
                    this.ocrDetection();
                }
                else {
                    this.detectIcon = 'action:close';
                }
            })
            .catch(error => {
                console.log(error);
                this.detectStarted = false;
                this.uploadDisabled = false;
                this.detectIcon = 'action:close';
            });
    }

    handleUploadFinished(event){
        this.resetStatus()
        var uploadedFiles = event.detail.files;
        var contentId = uploadedFiles[0].documentId;

        createContentUrl({
            contentDocumentId: contentId
        })
        .then(result => {
            console.log(this.contentUrl);
            this.contentUrl = result;
            this.cardVerification();
        })
    }

    handleFileChange(event){
        this.resetStatus()
        if(event.target.files.length > 0) {
            this.file = event.target.files[0];
            this.fileName = this.file.name;
            if (this.file.size > this.MAX_FILE_SIZE) {
                console.log(this.file.size);
                window.console.log('File Size is to long');
                return ;
            }
            this.detectStarted = true;
            this.uploadDisabled = true;
            this.fileReader= new FileReader();
            // set onload function of FileReader object  
            this.fileReader.onloadend = (() => {
                this.fileContents = this.fileReader.result;
                let base64 = 'base64,';
                let content = this.fileContents.indexOf(base64) + base64.length;
                this.fileContents = this.fileContents.substring(content);
                
                // Step 1 - Id Card Verification
                this.cardVerification();   
            });
            
            this.fileReader.readAsDataURL(this.file);
        }
    }
}