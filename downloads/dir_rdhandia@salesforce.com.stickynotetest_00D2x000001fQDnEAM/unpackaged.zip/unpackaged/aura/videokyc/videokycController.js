({
    doInit : function(component) {
    },
    canvasError : function(component){
        console.log('Error');
    },
    canvasLoad : function(component){
        console.log('load');
    },
    canvasSubscribed : function(component){
        console.log('subscribed');
    }
})